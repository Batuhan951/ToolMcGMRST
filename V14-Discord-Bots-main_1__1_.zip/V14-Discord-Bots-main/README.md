# V14 Ramal? Bot

# Proje Hakkında Bilgi

Projeyi Papazla Yaptık toplama bot gibi bişey 
biliyorum bakınca simdi çoğu eleman laf edicek ya işte kardeşim alıntı
ilk bi içine bak sonra konuş bunu diyen elemanların kendisi 2 satır kod dahi yazamıyor
neyse toplama bot alın kullanın hatası var ama ufak tefek botun çalışmasını engellemiyor onuda bilerek çözmedim
zaten paylaşıcam siz kendiniz çözersiniz + olarak görev komutunda invite görevini tanımlamadım onada göz atarsınız kendiniz


Projeye yardım eden asalaklar
`papazchavo. darkcim`


![image](https://cdn.discordapp.com/attachments/1009804086293565501/1173078238138998794/canavsramalkestat.png?ex=6562a53e&is=6550303e&hm=bc4d8bb26c6009138bf6e718c767e8c8f6c10453259115d5c918355c556f3dcc&)
![image](https://cdn.discordapp.com/attachments/1009804086293565501/1172838337850122260/ybasvuruuu.png?ex=6561c5d2&is=654f50d2&hm=6a7984dff10b3e20ab447eadb40e2cd8e97e4618ec32efb0d7b0312cb50db3a4&)
![image](https://cdn.discordapp.com/attachments/1009804086293565501/1171122194496114758/backupp.png?ex=655b8789&is=65491289&hm=369c4da38fff312892a4db850259e1f444b6a0c4bfd1336a9d94a052260b5ee1&)
![image](https://cdn.discordapp.com/attachments/1009804086293565501/1171122194215092234/yedeklemee.png?ex=655b8789&is=65491289&hm=1ace47a8c52b7775bd32e64ab26eadf46ec4e37b72c7bfddb47b1750e9f727dd&)
![image](https://cdn.discordapp.com/attachments/1009804086293565501/1170206675169464371/goreval.png?ex=655832e4&is=6545bde4&hm=5911884fdd4795e4460d9189ff6791118aaac13218a00a4018884ad2e1be503c&)
![image](https://cdn.discordapp.com/attachments/1009804086293565501/1170208044643254394/gorevler.png?ex=6558342b&is=6545bf2b&hm=e584df4b0f7bb50c0f8996b83b02375d7f626aa4b72ff3d46927405302d55fe7&)
![image](https://cdn.discordapp.com/attachments/1009804086293565501/1170206674762612826/songorulmee.png?ex=655832e4&is=6545bde4&hm=9e192e9f2067ace3ff91de5628989bfbbeea7d04f50b91c1297dff6402ad7de9&)
![image](https://cdn.discordapp.com/attachments/1009804086293565501/1170209037976092722/randevuu.png?ex=65583518&is=6545c018&hm=29b014e409c33f98bf8db82ab91ecb0f0bb61623200e030ea1fdfa2870395de6&)
![image](https://cdn.discordapp.com/attachments/1157800686248022177/1166446608863465623/image_10.png?ex=654a850f&is=6538100f&hm=6d89f53d80d1ff150b8e821476f62ca2d883c6640a92e226f0466e1ea463c77f&)
![image](https://cdn.discordapp.com/attachments/1165449404149403678/1165493865365643275/image_9.png?ex=65470dbf&is=653498bf&hm=c1479cc97b1417bccc31eb5d9b0ae7acf1723da233176c13977af4d79b69be74&)
![image](https://cdn.discordapp.com/attachments/1165449404149403678/1165481725946765322/dogrulamaa.png?ex=65470271&is=65348d71&hm=686b17d665d98a588febe49038c28ebe2d554fda0d7b82a04518a87be7c142c7&)
![image](https://cdn.discordapp.com/attachments/1165449404149403678/1165477958429966406/cmd_yasakla.png?ex=6546feee&is=653489ee&hm=6295f14c6ab7f3e134462a93657212171a77a27664f87722d69e66d8f52c4437&)
![image](https://cdn.discordapp.com/attachments/1165449404149403678/1165476830891999292/tweetsss.png?ex=6546fde1&is=653488e1&hm=78193296252a561f80aede1136407bbd63fdcad3195f8fb226c1fe79eb3ad4da&)
![image](https://cdn.discordapp.com/attachments/1165449404149403678/1165476098499424356/itiraf.png?ex=6546fd33&is=65348833&hm=8491be3718e79fc616ac24922e0ee74ad25482b065c04280673c5205ca1afa3c&)
![image](https://cdn.discordapp.com/attachments/1165449404149403678/1165473672887283772/otoreg.png?ex=6546faf1&is=653485f1&hm=dfe617fe4ac5c858cdffdb962a6beb7adde38f8efe0e7a04c018485d91742eb7&)
![image](https://cdn.discordapp.com/attachments/1165449404149403678/1165461319470809129/suslee.png?ex=6546ef6f&is=65347a6f&hm=1aa5f827121b3de29acb98b7202241284b119aed38ca7180c0afb81637c45cea&)
![image](https://cdn.discordapp.com/attachments/1157993674551087134/1165460953215803493/yoneticiliste.png?ex=6546ef18&is=65347a18&hm=db735420cb02a87c4108caf4ad0be88caad5d0876f66b18bf731526ded58360b&)
![image](https://cdn.discordapp.com/attachments/1165449404149403678/1165449455877771416/regkilit_kapat.png?ex=6546e463&is=65346f63&hm=ca11f82f86e6bd78cf141e0cff77c559783e37ea9b37bbe2f7d744f7ee235bbc&)
![image](https://cdn.discordapp.com/attachments/1165449404149403678/1165449455651270737/regkilit_ac.png?ex=6546e463&is=65346f63&hm=b88c7131144a4824e76248c7f95dac435376fd9f5d05b5e7ebb42d6af2f10712&)
![image](https://cdn.discordapp.com/attachments/1165449404149403678/1165449456108449873/kapalikayit.png?ex=6546e463&is=65346f63&hm=15d40cea77427904ce823fc35e9e549eb8ca490211dde2eedf2f3189e5e07bbf&)
![image](https://cdn.discordapp.com/attachments/1165449404149403678/1165450108117209128/say.png?ex=6546e4fe&is=65346ffe&hm=a346b84c7ec65fa6bdd23b1c259ccb477691ba1f9577f06b4ee952bacaa36c53&)
![image](https://cdn.discordapp.com/attachments/1165449404149403678/1165450108414984203/say_detayli.png?ex=6546e4fe&is=65346ffe&hm=91b39926213323e732d0719cb3acefd72c1299a67c9caa1df9ef688ab3eb34f6&)

![image](https://cdn.discordapp.com/attachments/1157800686248022177/1164342735537438801/gekle.png?ex=6542ddac&is=653068ac&hm=a4d9ca5fcc2c2831c8d9ffb2258760647da7cc4312bfb32e017d89819118382b&)
![image](https://cdn.discordapp.com/attachments/1157800686248022177/1164342736577626202/geklemenu.png?ex=6542ddac&is=653068ac&hm=7a915d423956085de2e44e1872e5229f479c0b21274481fa2bbb230e4ba38cf9&)
![image](https://cdn.discordapp.com/attachments/1157800686248022177/1164342736141434940/guvenlilistemenu.png?ex=6542ddac&is=653068ac&hm=4f6a9d8985dcd1a692b5fe534d093028c8b9d95b39edbb81825dbcb01ce1aabf&)
![image](https://cdn.discordapp.com/attachments/1157800686248022177/1164342735805886514/guvenlilistesi.png?ex=6542ddac&is=653068ac&hm=0dd140e1cacc6fa9520a268dd495193eb749ab244c9695a76a1d25d6eb0f810e&)

![image](https://cdn.discordapp.com/attachments/1009804086293565501/1156701384679370876/ramalassspapazkayit.png?ex=6515ed9c&is=65149c1c&hm=696e7a31834a91b34763c2f16a98d4766ec639fa63a7e98858254077cf750316&)


![image](https://cdn.discordapp.com/attachments/1009804086293565501/1156699704407642152/ramalpapazstat.png?ex=6515ec0b&is=65149a8b&hm=00327c8bc5fc933e5365855382a1e5b8017d61490302cd041f015320112a1692&)



![image](https://cdn.discordapp.com/attachments/1009804086293565501/1156699729640566815/ilgi.png?ex=6515ec11&is=65149a91&hm=a3f7927407f26ff1a8d8816bc8f7ba95f66a2545ea9a007f61170653f1ea4f99&)

![image](https://cdn.discordapp.com/attachments/1009804086293565501/1156699729896415283/ilgiver.png?ex=6515ec12&is=65149a92&hm=203a2e56072bae2b639534fc101f6fe46da468e0959a063ffd597b31f96c0ee0&)
